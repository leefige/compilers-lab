package test;

public class TestLv {
    int foo() {
        int a = 3;
        int b = 5;
        int d = 4;
        int c;
        int x = 100;
        if (a > b) {
            c = a + b;
            d = 2;
        }
        c = 4;
        return b * d + c;
    }
}
